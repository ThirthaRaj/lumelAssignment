export enum sortCriteria {
    Customer = 'customer',
    Order = 'order',
  }

export const allowedValues = ['customer', 'order'];